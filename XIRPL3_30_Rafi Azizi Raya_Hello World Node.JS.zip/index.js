 //Hello World
 console.log('Hello World');

 
//hello World WEB
var express = require('express');
var app = express();

// respond with "hello world" when a GET request is made to the homepage
app.get('/', function (req, res) {
  res.send('hello world');
})
app.listen('8080');


//Hello Arkademy - Express
const express = require('express');
const app = express();

app.get('/', function (req, res) {
  res.send('hello arkademy')
})
app.listen('8080');